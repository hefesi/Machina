# 19 — Roadmap

## Fase A — Core
- implementar Unit;
- Connection;
- Graph;
- State;
- scheduler temporal.

## Fase B — Memory
- working memory;
- episodic store;
- semantic consolidation.

## Fase C — Cognitive Core
- retrieval;
- association;
- prediction;
- reasoning;
- simulation.

## Fase D — Brain Integration
- workspace;
- world model;
- self model;
- agency.

## Fase E — Plasticity
- parameter update;
- connection update;
- structural proposals;
- sandbox;
- commit/rollback.

## Fase F — Organism
- observation interface;
- action intent;
- environment loop.

## Fase G — Validation
- benchmark suite;
- baselines;
- ablations;
- stress tests.

A primeira implementação deve ser pequena e mensurável, não uma tentativa imediata de construir AGI.
