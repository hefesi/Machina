# 12 — World Model e Self Model

O cérebro mantém dois modelos internos relacionados:

```text
WORLD MODEL                  SELF MODEL
    │                            │
    └──────────┬─────────────────┘
               ↓
          PREDICTION
               ↓
          SIMULATION
               ↓
           DECISION
```

World Model representa regularidades do ambiente.

Self Model representa o próprio sistema, suas capacidades, limitações e trajetória.

Uma experiência pode ser representada como:

`S_t → A_t → Environment → S_(t+1)`

e comparada com uma previsão:

`prediction → observation → prediction error → evaluation → learning`
