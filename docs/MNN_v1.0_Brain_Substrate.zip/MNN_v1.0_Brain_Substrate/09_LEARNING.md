# 09 — Aprendizado Contínuo

A MNN mantém três níveis de plasticidade:

1. Paramétrica:
`θ_(t+1) = Update(θ_t, loss, context)`

2. Conectiva:
`w_ij(t+1) = F_w(w_ij, activity, error, reward)`

3. Estrutural:
`G_(t+1) = F_G(G_t, experience, constraints)`

O objetivo é aprender continuamente sem destruir capacidades anteriores.

Métricas:
- retenção;
- adaptação;
- transferência;
- generalização;
- custo;
- estabilidade;
- crescimento estrutural.

Catastrophic forgetting é uma hipótese de falha a ser medida, não simplesmente assumida como resolvida.
