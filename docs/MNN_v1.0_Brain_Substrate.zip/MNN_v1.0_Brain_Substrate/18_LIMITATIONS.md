# 18 — Limitações e Hipóteses

A MNN v1.0 é uma arquitetura de pesquisa.

Ela não demonstra:
- AGI;
- consciência;
- experiência subjetiva;
- superioridade sobre Transformers;
- eficiência energética superior;
- autoaperfeiçoamento irrestrito.

Riscos:
- explosão combinatória;
- instabilidade dinâmica;
- crescimento estrutural;
- catastrophic forgetting;
- atribuição de crédito difícil;
- custo de validação;
- complexidade de depuração;
- circuitos inúteis ou redundantes.

A principal estratégia contra especulação é experimental: implementar o mínimo necessário e medir.
