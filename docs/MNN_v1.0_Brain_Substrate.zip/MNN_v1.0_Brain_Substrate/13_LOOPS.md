# 13 — Ciclos do Sistema

Existem três níveis.

## Interaction Loop

`Environment → Organism → Perception → Brain → Action Intent → Action System → Organism → Environment`

## Cognitive Cycle

`Workspace ↔ Memory ↔ Cognition → Agency → Action Intent`

Memory e Cognition podem interagir iterativamente.

## Learning Process

`Experience → Learning → Memory/Models/Strategies → Future Cycles`

Learning não é um estágio obrigatório do pensamento atual; ele transforma experiências em mudanças para ciclos futuros.
