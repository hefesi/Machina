# 15 — Modelo Temporal

A unidade temporal básica é um ciclo discreto `t`, mas componentes podem operar em escalas diferentes.

```text
Fast: neural activation / workspace
Medium: reasoning / planning
Slow: consolidation / structural plasticity
Very slow: identity / genome-level evolution
```

Não é necessário que todas as atualizações ocorram no mesmo passo.

O sistema deve registrar causalidade temporal suficiente para:
- atribuição de crédito;
- depuração;
- replay;
- comparação;
- rollback.
