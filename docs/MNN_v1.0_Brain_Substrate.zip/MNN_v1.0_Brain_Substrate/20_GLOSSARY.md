# 20 — Glossário

**MNN** — Memória/Neural Network com dinâmica persistente e plasticidade estrutural.

**Brain Graph** — grafo dinâmico que representa a organização funcional do cérebro.

**Unit** — unidade dinâmica com estado e memória local.

**Connection** — relação aprendível entre componentes.

**Workspace** — coalizão temporária de processamento global.

**Self Model** — representação persistente do próprio sistema.

**World Model** — representação interna de regularidades do ambiente.

**Agency** — mecanismo funcional de objetivos, decisão e intenção de ação.

**Structural Governor** — mecanismo de controle de alterações estruturais.

**Sandbox** — cópia/ramificação usada para testar mudanças antes do commit.

**Brain Genome** — conjunto de regras e invariantes estruturais de nível superior.

**Brain State** — estado atual de atividade, memória e contexto.

**Structural Version** — versão identificável da organização do grafo.
