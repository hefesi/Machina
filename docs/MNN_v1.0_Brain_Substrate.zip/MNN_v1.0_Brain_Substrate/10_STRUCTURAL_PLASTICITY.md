# 10 — Plasticidade Estrutural

A plasticidade estrutural pode:
- criar unidades;
- remover/podar unidades;
- criar/remover conexões;
- alterar tipos de relação;
- fundir circuitos;
- dividir circuitos;
- especializar componentes.

## Protocolo

```text
Experiência
   ↓
Detectar limitação
   ↓
Propor alteração
   ↓
Criar sandbox
   ↓
Executar testes
   ↓
Comparar baseline
   ↓
Avaliar utilidade/custo
   ├── rejeitar
   └── consolidar
```

A estrutura principal nunca deve ser alterada por uma proposta não validada quando a mudança tiver alto risco.

## Utilidade estrutural

Uma alteração deve ser avaliada por algo como:

`U_struct = Δperformance - λ1*Δcost - λ2*Δcomplexity - λ3*risk`

Os pesos `λ` são parâmetros experimentais.

## Rollback

Toda mudança consolidada deve possuir:
- identificador;
- parent version;
- motivo;
- evidência;
- métricas antes/depois;
- timestamp lógico;
- possibilidade de reversão.
