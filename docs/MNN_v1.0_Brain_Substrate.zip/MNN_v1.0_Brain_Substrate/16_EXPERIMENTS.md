# 16 — Plano Experimental v1.0

## E1 — Unidade
Comparar a unidade MNN com RNN/GRU/LSTM em tarefas de estado.

## E2 — Memória
Testar recuperação após longos intervalos e interferência.

## E3 — Continual Learning
Treinar A → B → C e medir retenção de A.

## E4 — Estrutura
Permitir mudanças topológicas e comparar com arquitetura fixa.

## E5 — Transferência
Treinar em famílias de tarefas e testar adaptação estrutural.

## E6 — Workspace
Testar se uma coalizão global melhora tarefas que exigem integração de múltiplas fontes.

## E7 — World/Self Model
Medir previsão do ambiente e calibração do modelo de capacidades próprias.

## E8 — Governança
Induzir propostas ruins e verificar rejeição/rollback.

## Métricas
- desempenho;
- retenção;
- adaptação;
- transferência;
- generalização;
- latência;
- memória;
- energia/custo;
- número de unidades;
- número de conexões;
- churn estrutural;
- estabilidade.

Toda alegação de vantagem deve ter baseline controlado.
