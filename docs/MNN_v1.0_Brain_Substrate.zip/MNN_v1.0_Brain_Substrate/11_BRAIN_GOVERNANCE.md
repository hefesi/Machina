# 11 — Brain Governance

O cérebro precisa separar aprendizagem de autoridade estrutural.

## Componentes

```text
Learning
   ↓
Change Proposal
   ↓
Structural Governor
   ↓
Sandbox
   ↓
Validation
   ├── Reject
   └── Commit
           ↓
       Brain Graph
```

O Governor controla:
- limites de crescimento;
- orçamento computacional;
- mudanças críticas;
- regressões;
- rollback;
- compatibilidade estrutural;
- proveniência.

## Brain Genome

O Genome define invariantes e limites que não devem ser alterados livremente:

- tipos primitivos de unidade;
- regras permitidas de conexão;
- limites de crescimento;
- requisitos de persistência;
- invariantes de segurança e integridade.

O Genome não é o estado atual do cérebro.
