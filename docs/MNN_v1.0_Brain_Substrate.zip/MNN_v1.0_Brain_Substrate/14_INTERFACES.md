# 14 — Interfaces

## Brain ↔ Organism

Perception Interface:
`Organism → Brain`

Action Interface:
`Brain → Organism`

O Brain trabalha com abstrações de observação e intenção. O Organism traduz isso para detalhes de sensores, ferramentas e atuadores.

## Brain internal APIs conceituais

- `observe(observation)`
- `activate(context)`
- `retrieve(query, context)`
- `reason(context)`
- `predict(state, action)`
- `plan(goal, context)`
- `decide(options, goal)`
- `propose_change(change)`
- `validate(change)`
- `commit(change)`
- `rollback(version)`
- `learn(experience)`
