# 17 — Invariantes da MNN v1.0

1. O cérebro é representado como estrutura dinâmica `B_t`.
2. Unidades possuem estado temporal.
3. Conexões são relações aprendíveis.
4. Memória não se reduz aos parâmetros.
5. Aprendizado pode atuar em parâmetros, conexões e estrutura.
6. Estrutura pode mudar, mas mudanças devem ser observáveis.
7. Mudanças de alto risco passam por proposta, teste e validação.
8. Alterações consolidadas devem possuir proveniência e rollback.
9. Workspace não é memória permanente.
10. Self não é sinônimo de consciência.
11. Agency não executa hardware diretamente.
12. Organism é a ponte com o ambiente.
13. Toda capacidade alegada exige teste.
14. O sistema deve poder ser comparado com baselines.
15. Crescimento estrutural deve possuir limites e orçamento.
